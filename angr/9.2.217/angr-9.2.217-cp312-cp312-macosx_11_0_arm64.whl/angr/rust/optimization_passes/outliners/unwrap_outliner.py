from __future__ import annotations
from collections import defaultdict

from angr.ailment.expression import Const, BinaryOp, VirtualVariable, Load, StringLiteral, Call
from angr.ailment.statement import Assignment, ConditionalJump, SideEffectStatement
from angr.rust.utils.ail import unwrap_stack_vvar_reference
from angr.rust.sim_type import RustSimTypeResult, RustSimTypeOption, RustSimTypeFunction, RustSimTypeInt
from angr.rust.mixins import CFAMixin, SRDAMixin, DFAMixin, CFGTransformationMixin, SSAVariableMixin
from angr.analyses.decompiler.optimization_passes.optimization_pass import OptimizationPassStage, OptimizationPass

RESULT_UNWRAP_FAILED_FUNCTION = "core::result::unwrap_failed"
OPTION_UNWRAP_FAILED_FUNCTION = "core::option::unwrap_failed"
UNWRAP_FAILED_FUNCTIONS = (RESULT_UNWRAP_FAILED_FUNCTION, OPTION_UNWRAP_FAILED_FUNCTION)
UNWRAP_FUNCTIONS = {
    "core::result::unwrap_failed": "core::result::unwrap",
    "core::option::unwrap_failed": "core::option::unwrap",
}


class UnwrapSimplifierState:
    """State for tracking unwrap pattern detection."""

    def __init__(
        self, conditional_jump_block, unwrap_failed_block, ownership_move_block, cmp_expr, unwrap_failed_func_name
    ):
        self.conditional_jump_block = conditional_jump_block
        self.unwrap_failed_block = unwrap_failed_block
        self.ownership_move_block = ownership_move_block
        self.cmp_expr = cmp_expr
        self.unwrap_failed_func_name = unwrap_failed_func_name

        self.err_or_none_discriminant = self._decide_err_or_none_discriminant()

        self.replacement = None
        self.stmt_to_replace = (None, None, None)
        self.stmts_to_remove = defaultdict(list)

    def _decide_err_or_none_discriminant(self):
        jump: ConditionalJump = self.conditional_jump_block.statements[-1]
        condition = jump.condition
        if not isinstance(condition, BinaryOp):
            return None
        if isinstance(condition.operands[1], Const):
            op = condition.op
            if (
                op == "CmpEQ"
                and isinstance(jump.true_target, Const)
                and (jump.true_target.value, jump.true_target_idx)
                == (
                    self.unwrap_failed_block.addr,
                    self.unwrap_failed_block.idx,
                )
            ) or (
                op == "CmpNE"
                and isinstance(jump.false_target, Const)
                and (jump.false_target.value, jump.false_target_idx)
                == (
                    self.unwrap_failed_block.addr,
                    self.unwrap_failed_block.idx,
                )
            ):
                return condition.operands[1].value
        return None


class UnwrapOutliner(OptimizationPass, CFAMixin, SRDAMixin, DFAMixin, CFGTransformationMixin, SSAVariableMixin):
    """Replace unwrap/expect patterns with simplified function call expressions."""

    ARCHES = None
    PLATFORMS = None
    STAGE = OptimizationPassStage.BEFORE_VARIABLE_RECOVERY
    NAME = "Outline unwrap function calls"

    def __init__(self, func, manager, **kwargs):
        super().__init__(func, manager, **kwargs)
        CFAMixin.__init__(self, self._graph, self.project)
        SRDAMixin.__init__(self, func, self._graph, self.project)
        DFAMixin.__init__(self)
        CFGTransformationMixin.__init__(self, self._graph)
        SSAVariableMixin.__init__(self, self)
        self.librust = self.project.kb.librust
        self.analyze()

    def _check(self):
        return self.project.is_rust_binary, None

    @staticmethod
    def _extract_vvar_from_cond(cond: BinaryOp):
        op0 = cond.operands[0]
        if isinstance(op0, Load):
            return unwrap_stack_vvar_reference(op0.addr)
        if isinstance(op0, VirtualVariable):
            return op0
        return None

    def _find_pred_and_succ(self, unwrap_failed_block):
        if self.num_predecessors(unwrap_failed_block) == 1:
            pred = self.get_one_predecessor(unwrap_failed_block)
            succs = [succ for succ in self._graph.successors(pred) if succ.addr != unwrap_failed_block.addr]
            if len(succs) == 1:
                return pred, succs[0]
        return None, None

    def _try_outline(self, unwrap_failed_block, unwrap_failed_func_name):
        pred, succ = self._find_pred_and_succ(unwrap_failed_block)
        if pred and succ:
            last_stmt = self.last_stmt(pred)
            if (
                isinstance(last_stmt, ConditionalJump)
                and isinstance(last_stmt.condition, BinaryOp)
                and (cmp_vvar := self._extract_vvar_from_cond(last_stmt.condition))
            ):
                call = self.get_terminal_vvar_value(cmp_vvar)
                if (
                    isinstance(call, Call)
                    and call.prototype is not None
                    and isinstance(call.prototype.returnty, (RustSimTypeResult, RustSimTypeOption))
                ):
                    enum_ty = call.prototype.returnty
                    variant = None
                    if (
                        isinstance(enum_ty, RustSimTypeResult)
                        and unwrap_failed_func_name == RESULT_UNWRAP_FAILED_FUNCTION
                    ):
                        variant = enum_ty.get_variant_by_name("Ok")
                    elif (
                        isinstance(enum_ty, RustSimTypeOption)
                        and unwrap_failed_func_name == OPTION_UNWRAP_FAILED_FUNCTION
                    ):
                        variant = enum_ty.get_variant_by_name("Some")
                    if variant and cmp_vvar.was_stack:
                        offset = cmp_vvar.stack_offset + variant.first_field_offset
                        size = variant.size - variant.first_field_offset
                        dst_vvar = self.new_stack_vvar(offset, size * 8, cmp_vvar.tags)
                        unwrap_func_name = UNWRAP_FUNCTIONS[unwrap_failed_func_name]
                        _, second_block = self.split_block(pred, last_stmt)
                        self.remove_block(unwrap_failed_block)
                        replacement = Call(
                            idx=last_stmt.idx,
                            target=StringLiteral(self.manager.next_atom(), unwrap_func_name, self.project.arch.bits),
                            prototype=RustSimTypeFunction(
                                args=[RustSimTypeInt(cmp_vvar.bits)], returnty=variant.type
                            ).with_arch(self.project.arch),
                            args=[cmp_vvar],
                            ret_expr=None,
                            **last_stmt.tags,
                        )
                        if replacement.prototype is not None:
                            replacement.prototype.returnty = variant.type.with_arch(self.project.arch)
                        replacement.bits = dst_vvar.bits
                        if second_block is not None:
                            second_block.statements[-1] = Assignment(
                                self.manager.next_atom(), dst_vvar, replacement, **last_stmt.tags
                            )
                        return
                # Outline unwrap without knowing the enum type
                unwrap_func_name = UNWRAP_FUNCTIONS[unwrap_failed_func_name]
                _first_block, second_block = self.split_block(pred, last_stmt)
                assert self.remove_block(unwrap_failed_block)
                replacement = Call(
                    idx=last_stmt.idx,
                    target=StringLiteral(self.manager.next_atom(), unwrap_func_name, self.project.arch.bits),
                    prototype=RustSimTypeFunction(args=[RustSimTypeInt(cmp_vvar.bits)], returnty=None).with_arch(
                        self.project.arch
                    ),
                    args=[cmp_vvar],
                    ret_expr=None,
                    **last_stmt.tags,
                )
                if second_block is not None:
                    second_block.statements[-1] = SideEffectStatement(last_stmt.idx, replacement, **last_stmt.tags)

    def _analyze(self, cache=None):
        for block in list(self._graph.nodes):
            # if block.addr == 0x40B2DE:
            #     import ipdb
            #
            #     ipdb.set_trace()
            if block in self._graph and (unwrap_failed_func_name := self.match_call(block, UNWRAP_FAILED_FUNCTIONS)):
                self._try_outline(block, unwrap_failed_func_name)

        self.out_graph = self._graph
