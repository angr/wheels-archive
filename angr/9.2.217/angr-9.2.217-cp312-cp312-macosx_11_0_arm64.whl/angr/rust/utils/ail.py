from __future__ import annotations

from angr.ailment import Block, Expression, UnaryOp, BinaryOp, Const, AILBlockViewer
from angr.ailment.expression import VirtualVariable, FunctionLikeMacro, Call
from angr.ailment.statement import Statement


class CallFinder(AILBlockViewer):
    """Find the first Call statement or expression in a block."""

    def __init__(self, include_macro=False):
        super().__init__()
        self.call = None
        self.include_macro = include_macro

    def _handle_Call(self, _stmt_idx: int, stmt: Call, _block: Block | None):
        if not self.call:
            self.call = stmt

    def _handle_CallExpr(self, expr_idx: int, expr: Call, stmt_idx: int, stmt: Statement | None, block: Block | None):  # pylint: disable=unused-argument
        if not self.call:
            self.call = expr

    def _handle_FunctionLikeMacro(
        self, expr_idx: int, expr: FunctionLikeMacro, stmt_idx: int, stmt: Statement | None, block: Block | None
    ):
        if not self.call and self.include_macro:
            self.call = expr


def find_call(obj: Block | Statement | Expression, include_macro=False):
    walker = CallFinder(include_macro)
    if isinstance(obj, Block):
        walker.walk(obj)
    elif isinstance(obj, Statement):
        walker.walk_statement(obj)
    elif isinstance(obj, Expression):
        walker.walk_expression(obj)
    return walker.call


def has_call(obj: Block | Statement | Expression, include_macro=False):
    return find_call(obj, include_macro) is not None


def get_terminal_call(block: Block):
    if block.statements:
        terminal = block.statements[-1]
        if isinstance(terminal, Call):
            return terminal
        finder = CallFinder()
        finder.walk_statement(terminal)
        return finder.call
    return None


def unwrap_stack_vvar_reference(expr) -> VirtualVariable | None:
    if (
        isinstance(expr, UnaryOp)
        and expr.op == "Reference"
        and isinstance(expr.operand, VirtualVariable)
        and expr.operand.was_stack
    ):
        return expr.operand
    return None


def unwrap_combo_reg_vvar_reference(expr) -> VirtualVariable | None:
    if (
        isinstance(expr, UnaryOp)
        and expr.op == "Reference"
        and isinstance(expr.operand, VirtualVariable)
        and expr.operand.was_combo_reg
    ):
        return expr.operand
    return None


def deref_vvar_and_offset(expr) -> tuple[VirtualVariable, int] | tuple[None, None]:
    """
    If expr is a dereference of a VirtualVariable (possibly with an offset), return the VirtualVariable and offset.
    Otherwise, return (None, None).
    """
    if isinstance(expr, UnaryOp) and expr.op == "Reference" and isinstance(expr.operand, VirtualVariable):
        return expr.operand, 0
    if isinstance(expr, BinaryOp) and expr.op == "Add":
        op0, op1 = expr.operands
        if (
            isinstance(op0, UnaryOp)
            and op0.op == "Reference"
            and isinstance(op0.operand, VirtualVariable)
            and isinstance(op1, Const)
        ):
            return op0.operand, op1.value_int
    return None, None


def extract_vvar_and_offset(expr) -> tuple[VirtualVariable, int] | tuple[None, None]:
    """
    If expr is a VirtualVariable (possibly with an offset), return the VirtualVariable and offset.
    Otherwise, return (None, None).
    """
    if isinstance(expr, VirtualVariable):
        return expr, 0
    if (
        isinstance(expr, BinaryOp)
        and isinstance(expr.operands[0], VirtualVariable)
        and isinstance(expr.operands[1], Const)
    ):
        return expr.operands[0], expr.operands[1].value_int
    return None, None


def unwrap_stack_vvar_reference_with_offset(expr) -> tuple[VirtualVariable, int] | tuple[None, None]:
    if isinstance(expr, UnaryOp) and expr.op == "Reference":
        if isinstance(expr.operand, VirtualVariable) and expr.operand.was_stack:
            return expr.operand, 0
        if (
            isinstance(expr.operand, BinaryOp)
            and expr.op == "Add"
            and isinstance(expr.operand.operands[0], VirtualVariable)
            and expr.operand.operands[0].was_stack
            and isinstance(expr.operand.operands[1], Const)
        ):
            return expr.operand.operands[0], expr.operand.operands[1].value_int
    return None, None


class CallVisitor(AILBlockViewer):
    """Visit all Call statements and expressions in a graph, invoking a callback."""

    def __init__(self, callback):
        super().__init__()
        self.callback = callback

    def _handle_CallExpr(self, expr_idx: int, expr: Call, stmt_idx: int, stmt: Statement | None, block: Block | None):  # pylint: disable=unused-argument
        self.callback(expr, block, stmt, is_expr=True)

    def visit(self, graph):
        for block in graph.nodes:
            self.walk(block)
