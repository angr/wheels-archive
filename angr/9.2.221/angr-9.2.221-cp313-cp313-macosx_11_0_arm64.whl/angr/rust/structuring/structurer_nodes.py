from __future__ import annotations

from collections import OrderedDict

from angr.ailment.statement import Statement
from angr.analyses.decompiler.structurer_nodes import INDENT_DELTA, BaseNode, SequenceNode
from angr.rust.sim_type import EnumVariant


class PatternMatchNode(BaseNode):
    """A Rust match expression node in the structured code tree."""

    __slots__ = (
        "addr",
        "arms",
        "default_node",
        "scrutinee",
    )

    def __init__(
        self,
        scrutinee,
        arms: OrderedDict[tuple[EnumVariant, tuple[Statement]], SequenceNode],
        default_node,
        addr=None,
    ):
        self.scrutinee = scrutinee
        self.arms = arms
        self.default_node = default_node
        self.addr = addr

    def dbg_repr(self, indent=0):
        indent_str = indent * " "
        s = indent_str + f"match {self.scrutinee} {{\n"
        for (variant, _), node in self.arms.items():
            s += indent_str + f"{variant} => {{\n" + node.dbg_repr(indent + INDENT_DELTA) + "\n},\n"
        return s


class IfLetNode(BaseNode):
    """A Rust if-let expression node in the structured code tree."""

    __slots__ = (
        "addr",
        "false_node",
        "pattern",
        "scrutinee",
        "true_node",
    )

    def __init__(
        self,
        pattern,
        scrutinee,
        true_node,
        false_node=None,
        addr=None,
    ):
        self.pattern = pattern
        self.scrutinee = scrutinee
        self.true_node = true_node
        self.false_node = false_node
        self.addr = addr

    def dbg_repr(self, indent=0):
        indent_str = indent * " "
        s = indent_str + f"if let {self.pattern} {{\n"
        s += indent_str + self.true_node.dbg_repr(indent + INDENT_DELTA) + "\n}"
        if self.false_node:
            s += ", else {\n" + self.false_node.dbg_repr(indent + INDENT_DELTA) + "\n}"
        return s
