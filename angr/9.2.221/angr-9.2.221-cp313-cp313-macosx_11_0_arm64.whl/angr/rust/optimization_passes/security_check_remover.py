from __future__ import annotations

from angr.analyses.decompiler.optimization_passes.optimization_pass import OptimizationPass, OptimizationPassStage
from angr.rust.mixins.cfa_mixin import CFAMixin
from angr.rust.mixins.cfg_transformation_mixin import CFGTransformationMixin

SECURITY_CHECK_FUNCTIONS = (
    "core::panicking::panic_bounds_check",
    "core::str::slice_error_fail",
    "core::panicking::panic_const::panic_const_div_by_zero",
    "core::panicking::panic_const::panic_const_rem_by_zero",
    "core::slice::index::slice_start_index_len_fail",
    "core::slice::index::slice_end_index_len_fail",
    "core::slice::index::slice_index_order_fail",
)


class SecurityCheckRemover(OptimizationPass, CFAMixin, CFGTransformationMixin):
    """Remove Rust bounds-check and overflow-check panic branches."""

    ARCHES = None
    PLATFORMS = None
    STAGE = OptimizationPassStage.BEFORE_VARIABLE_RECOVERY
    NAME = "Remove security check"

    def __init__(self, func, manager, **kwargs):
        super().__init__(func, manager, **kwargs)
        CFAMixin.__init__(self, self._graph, self.project)
        CFGTransformationMixin.__init__(self, self._graph)

        self.analyze()

    def _check(self):
        return self.project.is_rust_binary, None

    def _analyze(self, cache=None):
        for block in list(self._graph.nodes):
            if self.match_call(block, SECURITY_CHECK_FUNCTIONS):
                self.remove_block(block)
