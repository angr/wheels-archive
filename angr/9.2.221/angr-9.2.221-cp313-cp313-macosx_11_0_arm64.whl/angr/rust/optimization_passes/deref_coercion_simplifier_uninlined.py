from __future__ import annotations

from collections import defaultdict

from angr.ailment import AILBlockRewriter
from angr.ailment.expression import Call, VirtualVariable
from angr.ailment.statement import Assignment
from angr.analyses.decompiler.optimization_passes.optimization_pass import OptimizationPass, OptimizationPassStage
from angr.rust.mixins import CFAMixin, SRDAMixin

DEREF_COERCION_FUNCTIONS = [
    "core::ops::deref::Deref::deref",
    "core::ops::deref_mut::DerefMut::deref_mut",
]


class DerefCoercionSimplifierUninlined(OptimizationPass, SRDAMixin, CFAMixin, AILBlockRewriter):
    """
    Simplify explicit deref coercion operations that have not been inlined.
    1. Identify assignments where a VirtualVariable is assigned the result of a deref coercion function call.
    2. Record the mapping from the VirtualVariable to the argument of the deref coercion function.
    3. Traverse the AIL graph and replace occurrences of the VirtualVariable with the recorded argument.
    4. Remove the original assignment statements that performed the deref coercion.
    5. Update the AIL graph to reflect these changes.
    """

    ARCHES = None
    PLATFORMS = None
    STAGE = OptimizationPassStage.AFTER_VARIABLE_RECOVERY
    NAME = "Simplify explicit deref coercion operations (uninlined)"

    def __init__(self, func, manager, **kwargs):
        super().__init__(func, manager, **kwargs)
        SRDAMixin.__init__(self, func, self._graph, self.project)
        CFAMixin.__init__(self, self._graph, self.project)
        AILBlockRewriter.__init__(self)

        self._vvar_replacements = {}
        self._stmts_to_remove = defaultdict(list)

        self.analyze()

    def _check(self):
        return self.project.is_rust_binary, None

    def _handle_VirtualVariable(  # pyright: ignore[reportIncompatibleMethodOverride]
        self, expr_idx: int, expr: VirtualVariable, stmt_idx: int, stmt, block
    ):
        if isinstance(stmt, Assignment) and stmt.dst == expr and expr.varid in self._vvar_replacements:
            self._stmts_to_remove[block].append(stmt)
            return None
        if expr.varid in self._vvar_replacements:
            return self._vvar_replacements[expr.varid]
        return expr

    def _analyze(self, cache=None):
        for block in self._graph.nodes:
            for stmt in block.statements:
                if (
                    isinstance(stmt, Assignment)
                    and isinstance(stmt.dst, VirtualVariable)
                    and isinstance(stmt.src, Call)
                    and self.match_call(stmt.src, DEREF_COERCION_FUNCTIONS)
                    and stmt.src.args is not None
                    and len(stmt.src.args) == 1  # pyright: ignore[reportAttributeAccessIssue]
                ):
                    self._vvar_replacements[stmt.dst.varid] = stmt.src.args[0]
                    self._stmts_to_remove[block].append(stmt)

        for block in self._graph.nodes:
            self.walk(block)

        for block in self._graph.nodes:
            for stmt in self._stmts_to_remove[block]:
                if stmt in block.statements:
                    block.statements.remove(stmt)

        self.out_graph = self._graph
