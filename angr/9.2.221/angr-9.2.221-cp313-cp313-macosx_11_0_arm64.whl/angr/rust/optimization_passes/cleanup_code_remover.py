from __future__ import annotations

import logging

from angr.ailment.expression import Call, VirtualVariable
from angr.ailment.statement import Label, Return, SideEffectStatement
from angr.analyses.decompiler.optimization_passes.optimization_pass import OptimizationPass, OptimizationPassStage
from angr.rust.mixins import CFAMixin, CFGTransformationMixin, SRDAMixin
from angr.rust.utils.ail import find_call, get_terminal_call
from angr.rust.utils.demangler import demangle

CLEANUP_FUNCTIONS = (
    "free",
    "__rust_dealloc",
    "__rustc::__rust_dealloc",
    "close",
    "_close",
    "core::ptr::drop_in_place",
    "core::ops::drop::Drop::drop",
    "alloc::raw_vec::RawVecInner::deallocate",
    "smallvec::deallocate",
)


l = logging.getLogger(__name__)


class CleanupCodeRemover(OptimizationPass, CFGTransformationMixin, CFAMixin, SRDAMixin):
    """Remove cleanup code such as deallocation and drop calls."""

    ARCHES = None
    PLATFORMS = None
    STAGE = OptimizationPassStage.BEFORE_VARIABLE_RECOVERY
    NAME = "Remove cleanup code"

    def __init__(self, func, manager, **kwargs):
        super().__init__(func, manager, **kwargs)

        CFGTransformationMixin.__init__(self, self._graph)
        CFAMixin.__init__(self, self._graph, self.project)
        SRDAMixin.__init__(self, self._func, self._graph, self.project)

        self.analyze()

    def _check(self):
        return self.project.is_rust_binary, None

    @staticmethod
    def _is_simple_block(block):
        stmts = block.statements[:-1] if len(block.statements) > 0 else []
        return all(isinstance(stmt, Label) for stmt in stmts)

    def _should_remove(self, call):
        return self.match_call(call, CLEANUP_FUNCTIONS)

    def _collect_type_hint(self, call):
        name = self.get_call_target(call)
        if name:
            name = demangle(name)
            struct_ty = None
            if name.startswith("core::ptr::drop_in_place<") and name.endswith(">"):
                type_str = name[len("core::ptr::drop_in_place<") : -1].replace(",", ", ")
                struct_ty = self.project.kb.known_structs.get(type_str)
            elif name.startswith("core::ops::drop::Drop::drop<") and name.endswith(">"):
                type_str = name[len("core::ops::drop::Drop::drop<") : -1].replace(",", ", ")
                struct_ty = self.project.kb.known_structs.get(type_str)
            if struct_ty is not None and call.args and isinstance(call.args[0], VirtualVariable):
                self.project.kb.type_hints.add_type_hint(call.args[0], struct_ty, self._func.addr)

    def _remove_cleanup_calls(self):
        blocks_to_remove = set()
        for block in self._graph.nodes:
            call = get_terminal_call(block)
            if self._should_remove(call):
                self._collect_type_hint(call)
                if isinstance(block.statements[-1], Return):
                    block.statements[-1].ret_exprs = []
                elif not self._is_simple_block(block):
                    l.debug("Removed the last statement of\n%s", block)
                    block.statements = block.statements[:-1]
                else:
                    blocks_to_remove.add(block)
        for block in blocks_to_remove:
            self.remove_block(block)

    def _clean_return_exprs(self):
        for block in self._graph.nodes:
            if block.statements and isinstance(last_stmt := block.statements[-1], Return):
                call = find_call(last_stmt)
                last_stmt.ret_exprs = []
                if call and not self._should_remove(call):
                    call.bits = None  # pyright: ignore[reportAttributeAccessIssue]
                    new_stmts = block.statements.copy()
                    new_stmts[-1] = SideEffectStatement(self.manager.next_atom(), call, **call.tags)
                    new_stmts.append(last_stmt)
                    block.statements = new_stmts
        prototype = self._func.prototype
        if prototype:
            prototype = prototype.copy()
            prototype.returnty = None
            self._func.prototype = prototype

    def _adjust_returns_and_prototype(self):
        for block in self._graph.nodes:
            if block.statements and isinstance(last_stmt := block.statements[-1], Return):
                ret_expr = last_stmt.ret_exprs[0] if last_stmt.ret_exprs else None
                if isinstance(ret_expr, Call):
                    if self._should_remove(ret_expr):
                        self._clean_return_exprs()
                        break
                elif isinstance(ret_expr, VirtualVariable):
                    possible_values = self.get_terminal_vvar_values(ret_expr)
                    if any(isinstance(value, Call) and self._should_remove(value) for value in possible_values):
                        self._clean_return_exprs()
                        break

    def _analyze(self, cache=None):
        self._adjust_returns_and_prototype()
        self._remove_cleanup_calls()

        self.out_graph = self._simplify_graph(self._graph)
